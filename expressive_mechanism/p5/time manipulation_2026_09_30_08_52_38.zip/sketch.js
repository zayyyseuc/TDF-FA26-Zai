
let video;
let handPose;
let hands = [];


// =====================================================
// HAND
// =====================================================

let handX = 320;

let direction = "STOP";
let lastDirection = "RIGHT";

let fist = false;


// =====================================================
// VIRTUAL CLOCK
// =====================================================

// Initial time 12:00
let virtualMinutes = 12 * 60;

// Smoothed value, for display only
let displayMinutes = virtualMinutes;

// How many virtual minutes pass per real second
// Independent of hand movement speed
const TIME_RATE = 18;


// =====================================================
// SERVO
// =====================================================

// 360° continuous servo
//
// 1500 = stop
// 1400 = slow rotation in one direction
// 1600 = slow rotation in the other direction

const SERVO_STOP_US = 1500;

const SERVO_LEFT_US = 1400;

const SERVO_RIGHT_US = 1600;

let servoCommand = SERVO_STOP_US;


// =====================================================
// SERIAL
// =====================================================

let port;

let connectButton;

let lastSentCommand = null;

let lastSendTime = 0;

const SEND_INTERVAL = 50;


// =====================================================
// PRELOAD
// =====================================================

function preload() {

  handPose = ml5.handPose();

}


// =====================================================
// SETUP
// =====================================================

function setup() {

  createCanvas(
    640,
    480
  );

  angleMode(DEGREES);


  // ===================================================
  // CAMERA
  // ===================================================

  video = createCapture(
    VIDEO,
    () => {

      // Start HandPose once the camera is ready
      handPose.detectStart(
        video,
        gotHands
      );

    }
  );


  video.size(
    640,
    480
  );


  video.hide();


  // ===================================================
  // SERIAL
  // ===================================================

  port = createSerial();


  connectButton =
    createButton(
      "Connect Arduino"
    );


  connectButton.position(
    10,
    490
  );


  connectButton.mousePressed(
    connectArduino
  );
}


// =====================================================
// DRAW
// =====================================================

function draw() {

  background(
    12,
    14,
    18
  );


  // ===================================================
  // CAMERA BACKGROUND
  // ===================================================

  push();

  tint(
    255,
    30
  );


  translate(
    width,
    0
  );


  scale(
    -1,
    1
  );


  image(
    video,
    0,
    0,
    width,
    height
  );


  pop();

  noTint();


  // ===================================================
  // DRAW TIME FIELD
  // ===================================================

  drawTemporalField();


  // ===================================================
  // HAND DETECTED
  // ===================================================

  if (
    hands.length > 0
  ) {

    let hand =
      hands[0];


    // =================================================
    // PALM POSITION
    // =================================================
    //
    // Don't rely on the wrist alone
    // average several palm keypoints instead
    // for a more stable left/right decision
    //

    handX =
      getPalmX(
        hand
      );


    // Mirror
    handX =
      width -
      handX;


    // =================================================
    // FIST
    // =================================================

    fist =
      isFist(
        hand
      );


    // =================================================
    // FIST = STOP
    // =================================================

    if (fist) {

      direction =
        "STOP";


      servoCommand =
        SERVO_STOP_US;

    }


    // =================================================
    // OPEN HAND
    // =================================================

    else {

      let centerX =
        width / 2;


      // Center dead zone
      // Prevents flickering left/right when just crossing the center line
      let deadZone =
        30;


      // =================================================
      // LEFT
      // =================================================

      if (
        handX <
        centerX -
        deadZone
      ) {

        direction =
          "LEFT";


        lastDirection =
          "LEFT";


        servoCommand =
          SERVO_LEFT_US;
      }


      // =================================================
      // RIGHT
      // =================================================

      else if (
        handX >
        centerX +
        deadZone
      ) {

        direction =
          "RIGHT";


        lastDirection =
          "RIGHT";


        servoCommand =
          SERVO_RIGHT_US;
      }


      // =================================================
      // CENTER
      // =================================================
      //
      // When the hand is in the center,
      // keep the previous direction
      //

      else {

        direction =
          lastDirection;


        if (
          lastDirection ===
          "LEFT"
        ) {

          servoCommand =
            SERVO_LEFT_US;

        }

        else {

          servoCommand =
            SERVO_RIGHT_US;

        }
      }


      // =================================================
      // MOVE VIRTUAL TIME
      // =================================================
      //
      // deltaTime is in milliseconds,
      // so this doesn't depend on frame rate
      //

      let timeStep =
        TIME_RATE *
        (
          deltaTime /
          1000
        );


      if (
        direction ===
        "LEFT"
      ) {

        virtualMinutes -=
          timeStep;

      }


      else if (
        direction ===
        "RIGHT"
      ) {

        virtualMinutes +=
          timeStep;

      }


      // =================================================
      // KEEP TIME IN 0 - 1440
      // =================================================

      if (
        virtualMinutes <
        0
      ) {

        virtualMinutes +=
          1440;
      }


      if (
        virtualMinutes >=
        1440
      ) {

        virtualMinutes -=
          1440;
      }
    }


    // =================================================
    // HAND CURSOR
    // =================================================

    drawHandCursor();

  }


  // ===================================================
  // NO HAND
  // ===================================================

  else {

    direction =
      "STOP";


    servoCommand =
      SERVO_STOP_US;


    fist =
      false;
  }


  // ===================================================
  // CLOCK DISPLAY SMOOTHING
  // ===================================================

  displayMinutes =
    lerp(
      displayMinutes,
      virtualMinutes,
      0.15
    );


  // ===================================================
  // CLOCK
  // ===================================================

  drawClock();


  // ===================================================
  // UI
  // ===================================================

  drawUI();


  // ===================================================
  // SEND TO ARDUINO
  // ===================================================

  sendServoIfNeeded();
}



// =====================================================
// GET PALM X
// =====================================================

function getPalmX(hand) {

  let kp =
    hand.keypoints;


  // wrist
  // index MCP
  // middle MCP
  // ring MCP
  // pinky MCP

  let points = [
    0,
    5,
    9,
    13,
    17
  ];


  let totalX =
    0;


  for (
    let index of points
  ) {

    totalX +=
      kp[index].x;

  }


  return (
    totalX /
    points.length
  );
}



// =====================================================
// TEMPORAL FIELD
// =====================================================

function drawTemporalField() {

  let centerX =
    width / 2;


  // ===================================================
  // LEFT FIELD
  // ===================================================

  noStroke();


  fill(
    80,
    100,
    255,
    20
  );


  rect(
    0,
    0,
    centerX,
    height
  );


  // ===================================================
  // RIGHT FIELD
  // ===================================================

  fill(
    255,
    110,
    100,
    20
  );


  rect(
    centerX,
    0,
    centerX,
    height
  );


  // ===================================================
  // CENTER
  // ===================================================

  stroke(
    255,
    35
  );


  line(
    centerX,
    45,
    centerX,
    420
  );


  // ===================================================
  // LABELS
  // ===================================================

  noStroke();


  textAlign(
    CENTER,
    CENTER
  );


  textSize(
    12
  );


  // PAST
  fill(
    130,
    150,
    255
  );


  text(
    "← PAST",
    100,
    40
  );


  // PRESENT
  fill(
    255,
    130
  );


  text(
    "PRESENT",
    centerX,
    40
  );


  // FUTURE
  fill(
    255,
    140,
    130
  );


  text(
    "FUTURE →",
    540,
    40
  );
}



// =====================================================
// CLOCK
// =====================================================

function drawClock() {

  let cx =
    width / 2;


  let cy =
    220;


  let radius =
    110;


  // ===================================================
  // CLOCK FACE
  // ===================================================

  noStroke();


  fill(
    15,
    17,
    22,
    225
  );


  circle(
    cx,
    cy,
    radius * 2
  );


  noFill();


  stroke(
    255,
    80
  );


  strokeWeight(
    1
  );


  circle(
    cx,
    cy,
    radius * 2
  );


  // ===================================================
  // TICKS
  // ===================================================

  push();


  translate(
    cx,
    cy
  );


  for (
    let i = 0;
    i < 60;
    i++
  ) {

    let angle =
      i * 6 -
      90;


    let outer =
      radius -
      10;


    let inner;


    if (
      i % 5 ===
      0
    ) {

      inner =
        radius -
        22;


      stroke(
        255,
        180
      );


      strokeWeight(
        2
      );

    }

    else {

      inner =
        radius -
        15;


      stroke(
        255,
        55
      );


      strokeWeight(
        1
      );

    }


    let x1 =
      cos(angle) *
      inner;


    let y1 =
      sin(angle) *
      inner;


    let x2 =
      cos(angle) *
      outer;


    let y2 =
      sin(angle) *
      outer;


    line(
      x1,
      y1,
      x2,
      y2
    );
  }


  pop();


  // ===================================================
  // TIME VALUES
  // ===================================================

  let hours =
    floor(
      displayMinutes /
      60
    );


  let minutes =
    displayMinutes %
    60;


  let minuteAngle =
    minutes *
    6 -
    90;


  let hourAngle =
    (
      hours %
      12
    ) *
    30 +
    minutes *
    0.5 -
    90;


  // ===================================================
  // HOUR HAND
  // ===================================================

  stroke(
    255
  );


  strokeWeight(
    6
  );


  line(
    cx,
    cy,

    cx +
    cos(hourAngle) *
    52,

    cy +
    sin(hourAngle) *
    52
  );


  // ===================================================
  // MINUTE HAND
  // ===================================================

  stroke(
    205
  );


  strokeWeight(
    3
  );


  line(
    cx,
    cy,

    cx +
    cos(minuteAngle) *
    78,

    cy +
    sin(minuteAngle) *
    78
  );


  // ===================================================
  // CENTER
  // ===================================================

  noStroke();


  fill(
    255
  );


  circle(
    cx,
    cy,
    10
  );


  // ===================================================
  // DIGITAL TIME
  // ===================================================

  let h =
    floor(
      virtualMinutes /
      60
    );


  let m =
    floor(
      virtualMinutes %
      60
    );


  let timeText =
    nf(
      h,
      2
    ) +
    ":" +
    nf(
      m,
      2
    );


  noStroke();


  fill(
    255
  );


  textAlign(
    CENTER,
    CENTER
  );


  textSize(
    20
  );


  text(
    timeText,
    cx,
    355
  );
}



// =====================================================
// HAND CURSOR
// =====================================================

function drawHandCursor() {

  let y =
    390;


  // ===================================================
  // CONNECTION LINE
  // ===================================================

  stroke(
    255,
    35
  );


  line(
    handX,
    370,
    handX,
    410
  );


  // ===================================================
  // OUTER CIRCLE
  // ===================================================

  noStroke();


  fill(
    255,
    25
  );


  circle(
    handX,
    y,
    46
  );


  // ===================================================
  // INNER CIRCLE
  // ===================================================

  if (fist) {

    fill(
      120,
      255,
      170
    );

  }

  else if (
    direction ===
    "LEFT"
  ) {

    fill(
      130,
      150,
      255
    );

  }

  else {

    fill(
      255,
      140,
      130
    );

  }


  circle(
    handX,
    y,
    20
  );
}



// =====================================================
// UI
// =====================================================

function drawUI() {

  // ===================================================
  // STATE BOX
  // ===================================================

  noStroke();


  fill(
    0,
    175
  );


  rect(
    15,
    420,
    220,
    45,
    10
  );


  fill(
    255
  );


  textAlign(
    LEFT,
    CENTER
  );


  textSize(
    13
  );


  let stateText;


  if (fist) {

    stateText =
      "FROZEN";

  }

  else if (
    direction ===
    "LEFT"
  ) {

    stateText =
      "← MOVING INTO THE PAST";

  }

  else if (
    direction ===
    "RIGHT"
  ) {

    stateText =
      "MOVING INTO THE FUTURE →";

  }

  else {

    stateText =
      "WAITING";

  }


  text(
    stateText,
    30,
    442
  );


  // ===================================================
  // INSTRUCTION
  // ===================================================

  textAlign(
    RIGHT,
    CENTER
  );


  fill(
    255,
    130
  );


  textSize(
    11
  );


  text(
    "MOVE LEFT / RIGHT   •   FIST TO FREEZE",
    width - 20,
    442
  );


  // ===================================================
  // CONNECTION STATUS
  // ===================================================

  textAlign(
    LEFT,
    CENTER
  );


  textSize(
    11
  );


  if (
    port &&
    port.opened()
  ) {

    fill(
      100,
      255,
      150
    );


    text(
      "PHYSICAL CLOCK CONNECTED",
      20,
      18
    );


    connectButton.html(
      "Arduino Connected"
    );

  }

  else {

    fill(
      255,
      120,
      120
    );


    text(
      "PHYSICAL CLOCK DISCONNECTED",
      20,
      18
    );


    connectButton.html(
      "Connect Arduino"
    );

  }
}



// =====================================================
// FIST DETECTION
// =====================================================

function isFist(hand) {

  let kp =
    hand.keypoints;


  let wrist =
    kp[0];


  let fingers = [

    [8, 6],

    [12, 10],

    [16, 14],

    [20, 18]

  ];


  let curledCount =
    0;


  for (
    let finger of fingers
  ) {

    let tip =
      kp[
        finger[0]
      ];


    let pip =
      kp[
        finger[1]
      ];


    let tipDistance =
      dist(
        tip.x,
        tip.y,

        wrist.x,
        wrist.y
      );


    let pipDistance =
      dist(
        pip.x,
        pip.y,

        wrist.x,
        wrist.y
      );


    if (
      tipDistance <
      pipDistance
    ) {

      curledCount++;

    }
  }


  return (
    curledCount >=
    3
  );
}



// =====================================================
// HANDPOSE CALLBACK
// =====================================================

function gotHands(results) {

  hands =
    results;

}



// =====================================================
// CONNECT ARDUINO
// =====================================================

function connectArduino() {

  if (
    !port.opened()
  ) {

    port.open(
      9600
    );

  }

  else {

    port.close();

  }
}



// =====================================================
// SEND TO ARDUINO
// =====================================================

function sendServoIfNeeded() {

  if (
    !port ||
    !port.opened()
  ) {

    return;

  }


  let currentTime =
    millis();


  if (
    currentTime -
    lastSendTime <
    SEND_INTERVAL
  ) {

    return;

  }


  // Only send when the direction/state changes
  //
  // 1400
  // 1500
  // 1600

  if (
    servoCommand ===
    lastSentCommand
  ) {

    return;

  }


  lastSendTime =
    currentTime;


  lastSentCommand =
    servoCommand;


  port.write(
    String(
      servoCommand
    ) +
    "\n"
  );
}
